//package test;

import java.util.TreeSet;

public class TreeSetDemo 
{
	public static void main(String[] args) 
	{
		TreeSet tree = new TreeSet();
		//tree.add(1002);
		
		int x = 10;
		tree.add(x);
		
		Integer i = 254;		
		tree.add(i);
		
		//tree.add(x);
		
		Float f = 3.14f;
		tree.add(f);
		
		System.out.println(tree);
	}
}