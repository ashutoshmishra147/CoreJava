package test;
import java.util.ArrayList;
import java.util.HashSet;

public class ArrayListDemo 
{
	public static void main(String[] args) 
	{
		ArrayList list = new ArrayList();
		
		Integer iObj = new Integer(1002);
		String str1 = new String("Syntel");
		String str2 = "Syntel1";
		Double dObj = new Double(1002.0);
		
		list.add(iObj);
		list.add(str1);
		list.add(str2);
		list.add(dObj);
		
		int x = 1002;
		Integer iObj2 = 20005;
		int y = iObj2;
		
		list.add(x);
		
		/*System.out.println("Integer: "+iObj.hashCode());
		System.out.println("String1: "+str1.hashCode());
		System.out.println("String2: "+str2.hashCode());
		System.out.println("Double: "+dObj.hashCode());*/
		
		System.out.println(list);
	}
}