//package test;

import java.util.HashSet;

public class HashSetDemo 
{
	public static void main(String[] args) 
	{
		HashSet set = new HashSet();
		
		Integer iObj = new Integer(1002);
		String str1 = new String("Syntel");
		String str2 = new String("Syntelligence");
		Double dObj = new Double(1002.0);
		
		set.add(iObj);
		set.add(str1);
		set.add(str2);
		set.add(str2);
		set.add(dObj);
		
		int x = 1002;
		Integer iObj2 = 20005;
		int y = iObj2;
		
		set.add(x);
		
		System.out.println("Integer: "+iObj.hashCode());
		System.out.println("String1: "+str1.hashCode());
		System.out.println("String2: "+str2.hashCode());
		System.out.println("String22: "+str2.hashCode());		
		System.out.println("Double: "+dObj.hashCode());
		
		System.out.println(set);
	}
}