package exceptions;

public class Exception2 
{
	private static int compareStr(String str1, String str2)
	{
		try
		{
			if(str1.equalsIgnoreCase(str2))
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
			//return 100;
			System.exit(0);
		}
		finally
		{
			System.out.println("In finally");
		}
		return -1;
	}
	public static void main(String[] args) 
	{
		String str1 = null;
		String str2 = "welcome";
		
		int result = compareStr(str1, str2);
		System.out.println("Result: "+result);
	}
}