//package exceptions;

public class Exception1 
{
	public static void main(String[] args) 
	{
		System.out.println("Begin");
		try
		{
		int n1 = Integer.parseInt(args[0]);
		int n2 = Integer.parseInt(args[1]);
			
		int result = n1 / n2;
		System.out.println("Result: "+result);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
		System.out.println("please pass parameters.");
		}
		catch(ArithmeticException e)
		{
		System.out.println("Cant divide by zero.");
		}
		System.out.println("End");
	}
}