class Base
{
 void method1()
 {
  System.out.println("in Base class, without param");
 }

 void method1(int i)
 {
  System.out.println("in Base class using int param");
 }

 void method1(String s)
 {
  System.out.println("in Base class, using String param");
 }
 
 int method(int j)
 {
  System.out.println("in Base class, returning an int value");
  return j;
 } 

}


class Derived extends Base
{
 void method2()
 {
  System.out.println("in method 2");
 }

 public static void main(String args[])
 {
  Derived d1 = new Derived();
  d1.method1();
  d1.method2();
  d1.method1(10);
  d1.method1("test");
  d1.method(20);

  //Base b1 = new Base();
  // b1.method1();
 // b1.method2(); //generates an error.

  System.out.println("End of Program");
 

 }
 
}