/* program using constructors */


public class A
{
 
 A()
 {
  System.out.println("In normal constructor");
 }
 
 A(int i)
 {
   System.out.println("in int paramaterized constructor" + i);
 }
 
 A(int x, int y)
 {
   System.out.println("In constructor with 2 parameters x & y " + x + y);
 }
 
A(int x, String y)
 {
   System.out.println("In constructor with 2 parameters x & y " + x + y);
 }
 
 public static void main(String args[])
 {
  A a = new A();
  A a1 = new A(12);
  A a2 = new A(10,20);
  A a3 = new A(30,"abc");
 
 }

}