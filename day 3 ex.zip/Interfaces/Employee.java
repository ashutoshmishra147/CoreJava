package com.syntel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LS5028230
 */
public class Employee {
         private String empId;
         private String empName;
         private int age;
         private double salary;

    public Employee() {
        System.out.println("Default Constructor");
    }

  // Parameterized Constructor       
    public Employee(String empId, String empName, int age, double salary) {
        this.empId = empId;
        this.empName = empName;
        this.age = age;
        this.salary = salary;
    }     
         
    //Getter and Setter Methods to access the properties
    public String getEmpId() {
        return empId;
    }

    public void setEmpId(String empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }   

    @Override
    public String toString() {
        return "EmpId=" + empId + "\n Name=" + empName + "\n Age=" + age + "\n Salary=" + salary ;
    }
    
    
    
}
