/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syntel;

/**
 *
 * @author LS5028230
 */
public class Circle implements Shape{
    int radius;

    public Circle(int radius) {
        this.radius = radius;       
    }

    @Override
    public void calculateArea() {
        System.out.println("Area of a circle with radius:"+radius+" is:"+(pi*radius*radius));
    }
    
    
}
