/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//package com.syntel;


public interface Shape {
   double pi=3.14;
    void calculateArea();
}
