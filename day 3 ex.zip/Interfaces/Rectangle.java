/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syntel;

/**
 *
 * @author LS5028230
 */
public class Rectangle implements Shape {
    int x,y;

    public Rectangle(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void calculateArea() {
       System.out.println("Area of a Rectangle with Length:"+x+" and breadth :"+y+" is:"+(x*y));
    }
    
    
}
