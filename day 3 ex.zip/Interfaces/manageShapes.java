/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syntel;

/**
 *
 * @author LS5028230
 */
public class manageShapes {
    public static void main(String[] args){
        //Interfaces cannot be instantiated but reference variables of an interface can be created.
        
        Shape s;  
//s = reference variable

         s=new Square(10); // s is instantiated using constructor of Square class.
        s.calculateArea();
        
        s=new Rectangle(2,3);
// s is instantiated using constructor of Rectangle class.
        s.calculateArea();//
        
         s=new Circle(10);
// s is instantiated using constructor of Circle class.
        s.calculateArea();
    }
}
