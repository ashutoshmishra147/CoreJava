/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.syntel;


public class Square implements Shape{

    int x;

    public Square(int x) {
        this.x = x;
    }
    
    //@Override
    public void calculateArea() {
        System.out.println("Area of Square with length:"+x+" is :"+(x*x));
    }
    
}
