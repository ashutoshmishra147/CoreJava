public abstract Animal
{
   public void eat(Food food)
   {
        // do something with food.... 
   }

   public static void sleep(int hours)
   {
        try
	{
		// 1000 milliseconds * 60 seconds * 60 minutes * hours
		Thread.sleep ( 1000 * 60 * 60 * hours);
	}
	catch (InterruptedException ie) { /* ignore */ } 
   }

   public abstract void makeNoise();
}




public class Dog extends Animal
{
   public void makeNoise() { System.out.println ("Bark! Bark!"); }
}

public class Cow extends Animal
{

  p s v m(S a[])
  {
   Animal a = new Animal();// will not compile
  }

   public void makeNoise() { System.out.println ("Moo! Moo!"); }
}

