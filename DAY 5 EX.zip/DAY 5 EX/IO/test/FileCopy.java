package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy 
{
	public static void main(String[] args) 
	{
		File file = new File("D:/27-July-Java/test.txt");
		if(file.exists())
		{
			try
			{
				FileInputStream fis = new FileInputStream(file);
				FileOutputStream fos = new FileOutputStream("D:/27-July-Java/test2.txt");
				int ch;
				while((ch = fis.read()) != -1)
				{
					fos.write((char)ch);
				}
				System.out.println("file copied..");
				fos.close();
				fis.close();				
			}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}