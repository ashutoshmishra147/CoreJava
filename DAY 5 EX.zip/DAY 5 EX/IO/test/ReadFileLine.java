package test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileLine 
{
	public static void main(String[] args) 
	{
		File file = new File("D:/27-July-Java/test.txt");
		if(file.exists())
		{
			//FileInputStream fis = new FileInputStream("D:/27-July-Java/test.txt");
			try
			{
				//FileInputStream fis = new FileInputStream(file);
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				
				String line=null;
				while((line = br.readLine()) != null)
				{
					System.out.println(line);
				}
				br.close();
				fr.close();
			}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}