package test3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy 
{

	public static void main(String[] args) 
	{
		File file = new File("D:/kashi/kashi.txt");
		if(file.exists())
		{
			try
			{
				FileInputStream fis = new FileInputStream(file);
				FileOutputStream fos = new FileOutputStream("D:/kashi/copydata.txt");
				int ch;
				int space = 0,n=0;
				while((ch = fis.read()) !=-1)
				{
					if(ch == '\n')
					{
						n++;
						fos.write(System.getProperty("line.separator").getBytes());
					}
					if(ch == 32)
					{
						space++;
					}
					else
					{
						if(space>=1)
						{
							space=0;
							fos.write(' ');
							fos.write((char)ch);
							
						}
						else
							fos.write((char)ch);
					}
				}
				System.out.println("file copied");
				fis.close();
				fos.close();
			}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
			
		}
	}

}
