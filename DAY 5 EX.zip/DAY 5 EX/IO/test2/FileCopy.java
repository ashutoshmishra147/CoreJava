package test2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("D:/ashu/sourcefile.txt");
		// System.out.println(file.exists());
		try {
			FileInputStream fis = new FileInputStream(file);

			FileOutputStream fop = new FileOutputStream("D:/ashu/destfile.txt");
			int ch;
			int flag = 1;
			while ((ch = fis.read()) != -1) {

				if (ch == 32) {
					
					if (flag == 1) {
						flag++;
						System.out.print((char) ch);
						fop.write((char)ch);
					}

					else {
						//break;
					}

				} else {
					System.out.print((char) ch);
					fop.write((char)ch);
					flag = 1;
				}

				 //fop.write((char)ch);
			}
			System.out.println("File Copied");
			fop.close();
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException E) {
			E.printStackTrace();
		}

	}

}
