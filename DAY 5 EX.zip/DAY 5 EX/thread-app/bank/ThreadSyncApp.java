package bank;

public class ThreadSyncApp 
{
	public static void main(String[] args) 
	{
		Account account = new Account();
		account.setBalance(5000);
		
		Thread t1 = new Thread(account);
		Thread t2 = new Thread(account);
		t1.setName("Maria");
		t2.setName("Kim");
		t1.start();
		t2.start();
	}
}

class Account implements Runnable
{
	private double balance;
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void run()
	{
		for(int i=1; i<=10; i++)
		{
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
			withdraw(500);
		}
	}
	public synchronized void withdraw(double amt)
	{
		if(balance >= amt)
		{
			balance = balance - amt;
			String name = Thread.currentThread().getName();
			System.out.println(name+" withdraw "+amt+", and current balance: "+balance);
		}
		else
		{
			System.out.println("sorry dont have enough balance: "+balance);
		}
	}
}