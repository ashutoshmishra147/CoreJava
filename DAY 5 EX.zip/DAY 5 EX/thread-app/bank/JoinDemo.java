/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

/**
 *
 * @author LS5002117
 */
public class JoinDemo implements Runnable {

    public void run() {
        Thread th = Thread.currentThread();
        //Tests if this thread is alive
        System.out.println(th.getName()+" is alive "+th.isAlive());

    }

    public static void main(String args[]) throws Exception {
        Thread th = new Thread(new JoinDemo());
        th.start();
        // Waits at most 100 milliseconds plus 1000 nanoseconds for this thread to die.
        th.join(0, 10);
        //Tests if this thread is alive
        System.out.println(th.getName()+" is alive "+th.isAlive());
    }
} 
