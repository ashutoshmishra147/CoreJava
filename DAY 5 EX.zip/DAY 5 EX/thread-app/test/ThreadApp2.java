package test;

public class ThreadApp2 
{
	static void meth1()
	{
		System.out.println("meth1: Current Thread: "+Thread.currentThread().getName());
	}
	public static void main(String[] args) 
	{		
		System.out.println("Main: Current Thread: "+Thread.currentThread().getName());
		meth1();
		Thread t1 = new Thread(new Thread1());
		t1.start();
	}
}

class Thread1 extends Thread
{
	public void run()
	{
		System.out.println("run: Current Thread: "+Thread.currentThread().getName());
	}
}