package test;

public class ThreadApp1 
{
	static void childThread()
	{		
		System.out.println("Child Thread: "+Thread.currentThread().getName());
	}
	public static void main(String[] args) 
	{
		Thread thread = Thread.currentThread();
		String name = thread.getName();
		System.out.println("Thread Example: "+name);
		childThread();
	}
}