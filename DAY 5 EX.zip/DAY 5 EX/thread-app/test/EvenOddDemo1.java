package test;
public class EvenOddDemo1 {
	public static void main(String[] args) {		
		System.out.println("Lets see odd and even numbers using multithreading");
		Thread t2 = new Thread(new Odd1()); // New State
		Thread t1 = new Thread(new Even1()); // New State		
		t1.start();	// Runnable State	
		t2.start(); // Runnable State
		
		t2.setPriority(Thread.MAX_PRIORITY); // 10
		t1.setPriority(Thread.MIN_PRIORITY); // 1
	}
}
 class Even1 extends Thread {	 
	 // Running State
	 public void run () {		 
		 for(int i=0; i <=250; i++) {			 
			 if(i%2 == 0)
			 {
				 System.out.println(i+" is even");
				 try{
					 Thread.sleep(500);
				 }catch(InterruptedException e){ e.printStackTrace(); }
			 }
		 }		 
	 }
 } 
 class Odd1 extends Thread {	
	 // Running State
	 public void run () {		 
		 for(int i=0; i <=250; i++) {			 
			 if(i%2 != 0)
			 {
				 System.out.println(i+" is odd");
				 try{
					 Thread.sleep(500);
				 }catch(InterruptedException e){ e.printStackTrace(); }
			 }
		 }		 
	 }
 }