package test;

public class ThreadSyncApp 
{
	public static void main(String[] args) 
	{
		Account acc = new Account();
		acc.balance = 5000;
		Thread t1 = new Thread(acc);
		Thread t2 = new Thread(acc);
		t1.start();
		t2.start();
	}
}

class Account implements Runnable
{
	double balance;
	
	@Override	
	public void run() 
	{
		for(int i=1; i<=12; i++){
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			withdraw(500);	

			
		}
	}
	public  void withdraw(double amt)
	{
		if(amt <= balance)
		{
			balance = balance - amt;
			System.out.println("current balance: "+balance);
		}		
		else
			System.out.println("Sorry dont have enough balance: "+balance);
	}
}