package test;
public class EvenOddDemo {
	public static void main(String[] args) {		
		System.out.println("Lets see odd and even numbers using multithreading");
		Thread t2 = new Thread(new Odd()); // New State
		Thread t1 = new Thread(new Even()); // New State		
		t1.start();	// Runnable State	
		t2.start(); // Runnable State
	}
}
 class Even extends Thread {	 
	 // Running State
	 public void run () {		 
		 for(int i=0; i <=250; i++) {			 
			 if(i%2 == 0)
				 System.out.println(i+" is even");
		 }		 
	 }
 } 
 class Odd extends Thread {	
	 // Running State
	 public void run () {		 
		 for(int i=0; i <=250; i++) {			 
			 if(i%2 != 0)
				 System.out.println(i+" is odd");
		 }		 
	 }
 }