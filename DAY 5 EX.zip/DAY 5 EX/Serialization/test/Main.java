package test;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main 
{
	static Scanner s = new Scanner(System.in);
	public static Employee addEmployee()
	{
		System.out.print("Enter employee id: ");
		int id = s.nextInt();
		System.out.print("Enter employee name: ");
		String name = s.next();
		System.out.print("Enter employee id: ");
		double salary = s.nextDouble();
		
		Employee emp = new Employee(id, name, salary);
		
		return emp;
	}
	public static void viewEmployee(ArrayList<Employee> elist)
	{
		Iterator<Employee> itr = elist.iterator();
		while(itr.hasNext())
		{
			Employee e = itr.next();
			System.out.println(e);
		}
	}
	public static void saveEmployee(ArrayList<Employee> elist)
	{
		try
		{
			FileOutputStream fos = new FileOutputStream("D:/kashi/employees.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(elist);
			oos.close();
			fos.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) 
	{		
		ArrayList<Employee> list = new ArrayList<Employee>();		
		while(true)
		{
			System.out.println("1. Add new employee");
			System.out.println("2. View employees");
			System.out.println("3. Save employees");
			System.out.println("4. Exit");
			System.out.print("Enter your option: ");
			int option = s.nextInt();
			switch(option)
			{
			case 1:
				Employee emp = addEmployee();
				list.add(emp);
				break;
			case 2:
				viewEmployee(list);
				break;
			case 3:
				saveEmployee(list);
			case 4:
				System.exit(0);
			}
		}		
	}
}