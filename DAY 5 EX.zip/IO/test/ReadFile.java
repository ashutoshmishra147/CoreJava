package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ReadFile 
{
	public static void main(String[] args) 
	{
		File file = new File("D:/27-July-Java/test.txt");
		if(file.exists())
		{
			//FileInputStream fis = new FileInputStream("D:\java\jav.txt");
			try
			{
				FileInputStream fis = new FileInputStream(file);
				int ch;
				while((ch = fis.read()) != -1)
				{
					System.out.print((char)ch);
				}
				fis.close();				
			}
			catch(FileNotFoundException e)
			{
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}