/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bank;

/**
 *
 * @author LS5002117
 */
public class GetStateDemo implements Runnable {

    public void run() {
    	
        //Returns the state of this thread.
        Thread.State state = Thread.currentThread().getState();
        System.out.println("run"+Thread.currentThread().getName() + " " + state);
        
    }
    

    public static void main(String args[]) {
        Thread1 th1 = new Thread(new GetStateDemo());
        Thread.State state = th1.getState();
        System.out.println("main1: "+th1.getName() + " " + state);
        th1.start();
        try {
            th1.sleep(1000);
        } catch (Exception e) {
            System.out.println(e);
        }
        //Returns the state of the thread.
        Thread.State state1 = th1.getState();
        System.out.println("main2: "+th1.getName() + " " + state1);
    }
}  





