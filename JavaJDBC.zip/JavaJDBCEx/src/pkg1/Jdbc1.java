package pkg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Jdbc1 {

	
	@SuppressWarnings("deprecation")
	public static void main (String[] args)
    {
        Connection conn = null;

        try
        {
            String userName = "root";
            String password = "Mysql@2020";
            String url = "jdbc:mysql://localhost:3306/DBDEMO";
            Class.forName ("com.mysql.cj.jdbc.Driver");//.newInstance ();
            conn = DriverManager.getConnection (url, userName, password);
            
            Statement st = conn.createStatement();
            ResultSet rs =   st.executeQuery("select * from employee");
            System.out.println("_____________________________________________________");
            System.out.println( "Emp ID " + " Emp Name    " + " Dept No ");
            System.out.println("_____________________________________________________");
            while(rs.next())
               System.out.println(rs.getInt(1)+ "    "+ rs.getString(2)+ "        "+ rs.getString(3));
            st.close();
        }
        catch (Exception e)
        {
            System.out.println ("Cannot connect to database server... "+e);
        }
        finally
        {
            if (conn != null)
            {
                try
                {   
                    conn.close ();
                    System.out.println ("Database connection terminated");
                }
                catch (Exception e) 
                { 
                	System.out.println ("Exception is "+e);
                }
            }
        }
    }
}
