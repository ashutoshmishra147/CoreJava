package pkg1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertQuery {

	// JDBC driver name and database URL
		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://localhost:3306/DBDEMO";
		// Database credentials
		static final String USER = "root";
		static final String PASS = "Mysql@2020";
		public static void main(String[] args) {
			Connection conn = null;
			Statement stmt = null;
			try{
				//STEP 2: Register JDBC driver
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				//STEP 3: Open a connection
				System.out.println("Connecting to database...");
				conn = DriverManager.getConnection(DB_URL,USER,PASS);
				
				//STEP 4: Execute a query
				System.out.println("Creating table in given database...");
				
				stmt = conn.createStatement();
				String sql = "CREATE TABLE STUDENT " +
				"(id INTEGER not NULL, " +
				" fname VARCHAR(255), " +
				" lname VARCHAR(255), " +
				" age INTEGER, " +
				" PRIMARY KEY ( id ))";
				stmt.executeUpdate(sql);
				System.out.println("Created table in given database...");
				//Step 5: insertion of data
				System.out.println("Inserting records into the table...");
				stmt = conn.createStatement();
				String sqlQuery ="INSERT INTO Student VALUES (100, 'Krish', 'Kumar', 12)";
				stmt.executeUpdate(sqlQuery);
				sqlQuery = "INSERT INTO Student VALUES (101, 'Lata', 'M', 11)";
				stmt.executeUpdate(sqlQuery);
				sqlQuery= "INSERT INTO Student VALUES (102, 'Meena', 'K', 10)";
				stmt.executeUpdate(sqlQuery);
				sqlQuery= "INSERT INTO Student VALUES(103, 'Ron', 'Jack', 10)";
				stmt.executeUpdate(sqlQuery);
				System.out.println("Inserted records into the table...");
				
				
				//STEP 6: Clean-up environment
				stmt.close();
				conn.close();
			}catch(SQLException se){
				//Handle errors for JDBC
				se.printStackTrace();
				
			}catch(Exception e){
				//Handle errors for Class.forName
				e.printStackTrace();
				
			}finally{
				//finally block used to close resources
				try{
					if(stmt!=null)
						stmt.close();
				}catch(SQLException se2){
				}// nothing can be done
				
				try{
					if(conn!=null)
						conn.close();
				}catch(SQLException se){
					se.printStackTrace();
				}//end finally try
				
			}//end try
			System.out.println("Goodbye!");
		}//end main
}
