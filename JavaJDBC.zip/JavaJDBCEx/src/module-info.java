/**
 * 
 */
/**
 * @author ashutoshmishra
 *
 */
module JavaJDBCEx {
	requires java.sql;
}