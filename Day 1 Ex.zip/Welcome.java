class Welcome1{

  public static void main(String a[])
  {
   System.out.println("Hello World");
  }
}

class A{}

class B{

 public static void main(String a[])
  {
   System.out.println("Hello World in B");
  }
 }

