class MyClass12312
{
	//declaration of a constructor
	MyClass123()
	{	}
	
	void greet()
	{
	System.out.println("Hello there!!");
	}
	
  public static void main(String args[])
	{
	 System.out.println("Hello World!! ");
	}
 
}

public class MyClass12
{
 public static void main(String a[])
 {
  MyClass123 obj = new MyClass123();
  obj.greet();
	}
 
  
}