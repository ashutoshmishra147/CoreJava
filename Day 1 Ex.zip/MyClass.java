class MyClass123
{
	//declaration of a constructor
	MyClass123()
	{	}
	
	void greet()
	{
	System.out.println("Hello there!!");
	}
	
  /*public static void main(String args[])
	{
	 System.out.println("Hello World!! ");
	}*/
 
}

public class MyClass
{
 public static void main(String a[])
 {
  MyClass123 obj = new MyClass123();
  obj.greet();
	}
 
  
}

class A{}

class B{}


class C{}

/**

1) install jdk, downloaded from Oracle site
2) write the program using Notepad or any editor
3) open command prompt 
4) check for the enviornment variable path by typing path on the command prompt
5) if it is not set, u set the variable using set path=C:\...\bin;.;
6) type path again on the cmd prompt, u should see the path set in step 5
7) try javac, u shud get the parameters of javac
8) to compile - javac <filename>.java
9) to run - java <filename>

activity to be done
a) try with p s v Main(S a[]), 
b) without static keyword
c) try static public v m(S a[])
d) try p s v m(string args[])
e) try p s v m(String a[])
f) try p s int main(String args[]) returns 0;
g) have 2 main methods, 
     p s v m(String a[]) 
   & p s int main(String args[]) returns 0;

class <sourcefilename.java> extends Beta
{
main(){}
//private class B{}
}

private class Beta{}


write a program to showcase Inheritance with all keywords
public private protected default
//comment your learnings on that respective lines of code



1)program a calculator with options and print the results

1.prime no
2.odd no
3.even no
4.sqr root
5.square
0. Exit

2)java program for palindrome string

3)program to print 
*               and
**                1 2 3 4 
***		  5 6 7
****		  8 9
*****		  10








to set classpath
c:\> set classpath=C:\folder;.;


*/
