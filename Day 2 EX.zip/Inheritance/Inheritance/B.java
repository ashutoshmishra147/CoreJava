final class A {
 void meth() {
System.out.println("This is a final method.");
}
}

public static void main(String a[])
{
 A obj = new A();
 obj.meth();

}

class B extends A {
void meth() { // ERROR! Can't override.
System.out.println("Illegal!");
}
}