// Using super to overcome name hiding.
class A 
{
 int i;
}
// Create a subclass by extending class A.

class B extends A 
{
 int i; // this i hides the i in A
 B(int a, int b) //constructor
 {
  System.out.println("i of A, BEFORE INITIALIZATION: " + super.i);
  super.i = a; // i in A
  System.out.println("i of A, is called frm constructor of B: " + super.i);
  i = b; // i in B
  //super.i = 100;
  
 }
 void show() 
 {
  System.out.println("i in superclass: " + super.i);
  System.out.println("i in subclass: " + i);
 } 
}
class UseSuper 
 {
  public static void main(String args[]) {
  B obj = new B(1, 2);
  B obj1 = new B(5,6,7);// will give error
  obj.show();
 }
}