public class MyA
{
 //final int j;
//access specifiers - class , method, variables, constructors 
 MyA() // constructor - default access specifier
 { //j=15;
   System.out.println("This is a constructor"); 
 }

 MyA(int i)
 {
  System.out.println("This is a constructor with int param"); 
 }

 MyA(String str)
 {
  System.out.println("This is a constructor with String param"); 
 }
  private void meth() // default access specifier
 {
  //j=100;
  System.out.println("This is method of MyA Class" );
 }
 
 /*static void main1()
  {
   //MyA obj = new MyA();
   //obj.meth();
   System.out.println("This is in main1 method." );
  }*/

 public static void main(String a[])
  {
   MyA obj = new MyA();
   MyA obj1 = new MyA(105);
   MyA obj2 = new MyA("Hello");

   obj.meth();
   obj1.meth();
   obj2.meth();
   //main1();
  }
}

class B extends MyA
{
  B(int k)
  {
   System.out.println("This is in constructor of B with Param");
  }

   void meth() //overriding method
  {
   System.out.println("This is in class B.");
  }

 public static void main(String a[])
  {
   B objB = new B(4);//class MyA constructor gets called 1st
   objB.meth();// calling method of B class
   
    //obj1.meth();
   //obj2.meth();
   //main1();
  }
}



//single line

/*
this
is
multi line 
comment */


/** this code is written by AShutosh
on  10-03-18, for java batch
*/

//Cannot copy the data or screenshots
  
 