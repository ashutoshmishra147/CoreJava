package test;

import java.util.Comparator;

public class EmployeeIdComparator implements Comparator<Employee1> 
{
	@Override
	public int compare(Employee1 emp1, Employee1 emp2) 
	{
		System.out.println("--- compare ---");
		if(emp1.emp_id == emp2.emp_id)
			return 0;
		else if(emp1.emp_id > emp2.emp_id)
			return 1;
		else
			return -1;
	}
}
