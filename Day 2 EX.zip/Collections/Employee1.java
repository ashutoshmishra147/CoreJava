package test;

public class Employee1 implements Comparable<Employee1>
{
	int emp_id;
	String emp_name;
	double emp_salary;
	
	public Employee1(int emp_id, String emp_name, double emp_salary) 
	{		
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_salary = emp_salary;
	}
	@Override
	public String toString() {
		return "(emp_id=" + emp_id + ", emp_name=" + emp_name
				+ ", emp_salary=" + emp_salary + ")\n";
	}
	@Override
	public int compareTo(Employee1 emp) 
	{
		System.out.println("--- compareTo ---");
		if(this.emp_id == emp.emp_id)
			return 0;
		else if(this.emp_id > emp.emp_id)
			return 1;
		else
			return -1;
	}
	
}
