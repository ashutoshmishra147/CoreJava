package test;

import java.util.TreeSet;

public class TreeSetDemo3
{
	public static void main(String[] args) 
	{
		TreeSet<Employee1> set = new TreeSet<Employee1>();
		
		Employee1 emp1 = new Employee1(1001, "Rajiv", 50000);
		Employee1 emp2 = new Employee1(1002, "Rajiv2", 5000);
		
		set.add(emp1);
		set.add(emp2);
		
		System.out.println(set);
	}
}