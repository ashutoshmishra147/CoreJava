package test;

import java.util.HashSet;

public class ArrayListDemo2 
{
	public static void main(String[] args) 
	{
		HashSet set = new HashSet();
		Employee emp1 = new Employee(1001, "Rajiv", 50000);
		Employee emp2 = new Employee(1002, "Rajiv2", 5000);
		Employee emp3 = new Employee(1001, "Rajiv", 50000);
		
		//System.out.println("emp1: "+emp1.hashCode());
		//System.out.println("emp2: "+emp2.hashCode());
		//System.out.println("emp3: "+emp3.hashCode());
		
		set.add(emp1);
		set.add(emp2);
		set.add(emp3);
		System.out.println(set);
	}
}