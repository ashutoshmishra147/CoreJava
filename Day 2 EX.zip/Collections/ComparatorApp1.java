package test;

import java.util.ArrayList;
import java.util.Collections;

public class ComparatorApp1 
{
	public static void main(String[] args) 
	{
		ArrayList<Employee1> list = new ArrayList<Employee1>();
		list.add(new Employee1(1001, "Raj1", 4500));
		list.add(new Employee1(1004, "Raj2", 6000));
		list.add(new Employee1(1003, "Raj3", 5500));
		
		Collections.sort(list, new EmployeeIdComparator());
		
		System.out.println(list);
		
	}
}