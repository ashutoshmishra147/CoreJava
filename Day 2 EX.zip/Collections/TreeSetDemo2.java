package test;

import java.util.TreeSet;

public class TreeSetDemo2 
{
	public static void main(String[] args) 
	{
		TreeSet<Integer> tree = new TreeSet<Integer>();
		tree.add(1002);
		
		int x = 10;
		tree.add(x);
		
		Integer i = 254;		
		tree.add(i);
		
		tree.add(x);
		
		int f1 = (int)3.14;
		//Float f = new Float(3.14);
		tree.add(f1);
		
		System.out.println(tree);
	}
}