package test;

public class Employee 
{
	private int emp_id;
	private String emp_name;
	private double emp_salary;
	
	public Employee(int emp_id, String emp_name, double emp_salary) 
	{		
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_salary = emp_salary;
	}
	@Override
	public String toString() {
		return "(emp_id=" + emp_id + ", emp_name=" + emp_name
				+ ", emp_salary=" + emp_salary + ")";
	}
	@Override
	public int hashCode() {		
		final int prime = 31;
		int result = 1;
		result = prime * result + emp_id;
		result = prime * result
				+ ((emp_name == null) ? 0 : emp_name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(emp_salary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		System.out.println("generating hashcode..."+result);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		System.out.println("checking equality...");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (emp_id != other.emp_id)
			return false;
		if (emp_name == null) {
			if (other.emp_name != null)
				return false;
		} else if (!emp_name.equals(other.emp_name))
			return false;
		if (Double.doubleToLongBits(emp_salary) != Double
				.doubleToLongBits(other.emp_salary))
			return false;
		return true;
	}
	
	
		
}
