// Demonstrate a two-dimensional array.
class TwoDArray
{
  public static void main(String args[])
  {
   int twoD[][]= new int[4][5];
   int i, j, k = 0;
   
 
       for(i=0; i<4; i++)
       {
        for(j=0; j<5; j++)
	  {
 	   //twoD[i][j] = k;
           //k++;
           System.out.print("[" + i + "][" + j + "] ");
       	  }
          System.out.println();
	}
  }
}


/*

use print statements at regular intervals in the above prog. and give explaination of each value of i j k at regular intervals.

*/
