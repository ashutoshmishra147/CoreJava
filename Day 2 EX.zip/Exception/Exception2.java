//package exceptions;

public class Exception2 
{
	private static int compareStr(String str1, String str2) 
	{
		try
		{
			if(str2.equalsIgnoreCase(str1))
		        	System.out.println("in if stmt");
			else
				//throw new Exception();
			  System.out.println("In else block");
			
		}
		catch(Exception e)
		{      e.printStackTrace();
			//return 100;
			System.exit(0);//this will terminate the program
		}
		finally
		{
			System.out.println("In finally block");
		}
		return -1001;
	}
	public static void main(String[] args) 
	{
		String str1 ="WelcOmes";
		String str2= "different";
		
		int result = compareStr(str1, str2);
		System.out.println("Result: "+result);
	}
}