package com.syntel.p1;

import java.lang.*;


public class Arguments
 {
    public static void main (String args[]) 
    {
        for (int i = 0; i < args.length; i++)
            System.out.println(args[i]);
    }
}

// to compile = javac -d Arguments.java
//to run = java com.p1.Arguments 10 30 two


//activity 

//check the arguments, if they are of type integer, print them, else display an exception