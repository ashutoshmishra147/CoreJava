//package p3;

public class OverloadingDemo 
{
	public void meth1(int var)
	{
		System.out.println("--- integer ---");
	}
	public void meth1(float var)
	{
		System.out.println("--- float ---");
	}
	public void meth1(long var)
	{
		System.out.println("--- long ---");
	}
	public void meth1(double var)
	{
		System.out.println("--- double ---");
	}	
	public static void main(String[] args) 
	{
		byte b = 100;
		OverloadingDemo obj = new OverloadingDemo();
		obj.meth1(b);
		obj.meth1(10.0F);
	}
}
