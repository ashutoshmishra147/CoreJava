//package p3;

public class OverloadingDemo2 
{
	public void meth1(String str)
	{
		System.out.println("--- String ---");
	}
	public void meth1(Object str)
	{
		System.out.println("--- Object ---");
	}
	public void meth1(StringBuffer str)
	{
		System.out.println("--- StringBuffer ---");
	}
	public static void main(String[] args) 
	{
		OverloadingDemo2 obj = new OverloadingDemo2();
		
		String str1 = "Java";
		obj.meth1(str1);
		
		String str2 = new String("Java");
		obj.meth1(str2);
		
		str2 = null;
		obj.meth1(str2);
		
		A aobj = new A();
		obj.meth1(aobj);
	}
}

class A
 {
 public void myMeth()
 { System.out.println(" ");}

}