package p3;
 abstract class Instrument 
{
	public abstract Instrument play();
	
	public void sing()
	{
	 System.out.println("hi");
	}
	
}
