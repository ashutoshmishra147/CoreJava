package p3;

public class Guitar extends Instrument
{
	public Instrument play()
	{
		System.out.println("Guitar is playing  tin  tin  tin ");
		return null;
	}
}
