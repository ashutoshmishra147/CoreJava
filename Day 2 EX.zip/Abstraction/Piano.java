package p3;

public class Piano extends Instrument
{
	public Instrument play()
	{
		System.out.println("Piano is playing  tan tan tan tan");
	return null;
	}
}
