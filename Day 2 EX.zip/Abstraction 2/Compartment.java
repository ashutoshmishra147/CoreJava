package Compartment;

public abstract class Compartment {

	abstract public void  notice();
}
