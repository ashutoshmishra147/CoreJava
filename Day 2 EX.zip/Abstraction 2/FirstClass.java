package Compartment;

public class FirstClass extends Compartment {
	public void notice()
	{
		System.out.println("This is firstclass  compartment");
	}

}
