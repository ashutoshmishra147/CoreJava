package Compartment;

public class General extends Compartment{
	public void  notice()
	{
		System.out.println("Shittt  General class");
	}

}
