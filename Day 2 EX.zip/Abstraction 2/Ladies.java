package Compartment;

public class Ladies extends Compartment{
	public void  notice()
	{
		System.out.println("Ohh Ladies class!!!");
	}
}
