package Compartment;

import java.util.Random;
import java.util.Scanner;

public class TestCompartment {

	public static void main(String[] args) {
		
      Compartment comp []=new Compartment[10];
      
      for(int i=0;i<10;i++)
      {
    	  int random = new Random().nextInt(4);
      switch(random)
      {
      case 0:
      comp[random]=new FirstClass();
     
      break;
      
      case 1:
          comp[random]=new General();
         
          break;
          
      case 2:
          comp[random]=new Ladies();
        
          break;
          
      case 3:
          comp[random]=new Luggage();
        
          break;
      
          
      }
      
      comp[random].notice();
      
      
      }
	}
}

