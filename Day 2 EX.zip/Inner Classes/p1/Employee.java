package p1;

public class Employee 
{
	private int empid;
	private String empname;
	
	private class Address
	{
		private String city;
		private String state;
		private String pin;
		
		@Override
		public String toString() {
			return "Address [city=" + city + ", state=" + state + ", pin="
					+ pin + "]";
		}
		
		
	}
	
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + "]";
	}
	
	/*public static void main(String args[])
	{
		Employee emp = new Employee();
		Address address = emp.new Address();
		address.city="Mumbai";
		address.state="MH";
		address.pin="400001";
		
		System.out.println(emp);
		System.out.println(address);
		
	}*/
	
	public static void main(String args[])
	{
		Employee emp = new Employee();
		Employee.Address address = new Employee.Address();
		System.out.println(emp);
		System.out.println(address);
	}
}
