package p1;
public class Course
{
	private int id;
	private String name;

	public Course(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
	public void showCourse()
	{
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
	}
}