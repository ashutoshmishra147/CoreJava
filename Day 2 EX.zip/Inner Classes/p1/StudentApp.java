package p1;

import java.util.Scanner;


public class StudentApp 
{
	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter how many courses you want: ");
		int size = scanner.nextInt();
		
		Course courses[] = new Course[size];
		for(int i=0; i<size; i++)
		{
			System.out.print("Enter course id: ");
			int cid = scanner.nextInt();
			System.out.print("Enter course name: ");
			String cname = scanner.next();
			
			courses[i] = new Course(cid, cname);
		}
		
		Student s1 = new Student(1, "Rajesh", "9/6/1995");		
		s1.setCourse(courses);
		s1.showStudent();
	}
}