package p1;
public class Student
{
	private int rollno;
	private String name;
	private String dob;
	private Course course[];
	
	public Student(int rollno, String name, String dob)
	{
		this.rollno = rollno;
		this.name = name;
		this.dob = dob;
	}
	public void setCourse(Course course[])
	{
		this.course = course;
	}
	public void showStudent()
	{
		System.out.println("Roll number: "+rollno);
		System.out.println("Name: "+name);
		System.out.println("DOB: "+dob);
		System.out.println("Course Info: ");
		for(Course c : course)
			c.showCourse();
	}

}