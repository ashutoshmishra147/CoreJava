//package Fundamentals; - single line comment

/* multi line

comment
*/

/**
 *
 * @author LS5002117 Documentation comment
 */
 
import java.util.Scanner;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


public class ScannerDemo {
    public static void main(String[] args) 

  {

    double number;

    Scanner in = new Scanner(System.in);

    System.out.println("Enter your gross income: ");

    if (in.hasNextInt())

    {

      number = (double)in.nextInt();

      System.out.println("You entered " + number);

    }

    else if (in.hasNextFloat())

    {

      number = (double)in.nextFloat();

      System.out.println("You entered " + number);

    }

    else if (in.hasNextDouble())

    {

      number = in.nextDouble();

      System.out.println("You entered " + number);

    }              

    else

      System.out.println("Token not an integer or a real value.");    

  }


}
