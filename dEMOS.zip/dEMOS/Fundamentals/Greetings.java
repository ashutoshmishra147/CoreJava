/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Fundamentals;

/**
 *
 * @author LS5002117
 */
public class Greetings {
    public static void printGreetings(String... names) {
        for (String n : names) { 
            System.out.println("Hello " + n + ". "); 
        }       
    }    
      
    
    public static void main(String[] args) {
        printGreetings("Paul", "Susan","Jenny","Benjamin");       
    }  

//    public static void main(String... args) {
//        System.out.println("Command Line Arguments");
//        printGreetings(args);                     
//    } 
}
