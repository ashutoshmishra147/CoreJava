// Class and Object initialization showing the Object Oriented concepts in Java
class Cube {

	int length = 10;
	int breadth = 10;
	int height = 10;
	public static int numOfCubes = 0; // static variable
	public static int getNoOfCubes() { //static method
		return numOfCubes;
	}
	public Cube() {
		numOfCubes++; //
	}
}

public class CubeStaticDemo {

  
	public static void main(String args[]) {
	  Cube c = new Cube();
    Cube c1 = new Cube();
    Cube c2 = new Cube();
    
		System.out.println("Number of Cube objects = " + Cube.numOfCubes);
		System.out.println("Number of Cube objects = "
				+ c1.getNoOfCubes());
				
	}
}