package Fundamentals;

 
public class TestAnonymousInnerClass { 
    void TestAnonymousInnerClass(){ 
        Thread t=new Thread( 
        //This is the Anonymous Inner Class.Which don't have any name for class. 
        new Runnable() { 
        @Override
        public void run() { 
        System.out.println("Hi,This is example of anonymous Inner Class."); 
        } 
        }); 
        t.start(); 
    } 
    public static void main(String[] args) { 
        TestAnonymousInnerClass outerClass=new TestAnonymousInnerClass(); 
        outerClass.TestAnonymousInnerClass(); 
    } 
}	 

