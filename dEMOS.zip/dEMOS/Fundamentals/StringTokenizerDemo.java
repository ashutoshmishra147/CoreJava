import java.util.*;
public class StringTokenizerDemo
{
  public static void main(String args[])
  {
    int idx=0; int tokenCount;
    String words[]=new String [500];
    String message="The text of the message to be scanned.";
    StringTokenizer st=new StringTokenizer(message);
    tokenCount=st.countTokens();
    System.out.println("Number of tokens = " + tokenCount);
    while (st.hasMoreTokens()) // is there stuff to get?
        {words[idx]=st.nextToken(); idx++;}
    for (idx=0;idx<tokenCount; idx++)
        {System.out.println(words[idx]);}
  }
}