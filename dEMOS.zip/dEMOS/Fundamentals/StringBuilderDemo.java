public class StringBuilderDemo {
public static void main(String args[])
{
char[] charArray = new char[13];
StringBuilder sb = new StringBuilder("Learning java with examples");
System.out.println("Using charAt() method : "+sb.charAt(9));
System.out.println("Using deleteCharAt() method : "+sb.deleteCharAt(26));
 
sb.getChars(0,13,charArray,0);
System.out.print("Using getChars() method : ");
System.out.println(charArray);
 
System.out.println("Using length() method : "+sb.length());
System.out.println("Using replace() method : "+sb.replace(14,26,"for beginners"));
 
sb.setCharAt(9,'J');
System.out.println("Using setCharAt() method : "+sb);
 
sb.append(" with examples");
System.out.println("Using append() method : "+sb);
 
sb.setLength(13);
System.out.println("Using setLength() method : "+sb);
}
