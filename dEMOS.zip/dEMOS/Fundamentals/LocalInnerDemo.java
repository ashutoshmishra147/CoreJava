public class LocalInnerDemo {

public static void main(String[] args) {
    final int k = 1;
    class ImALocalInner {
    public void write() {
        System.out.println("writing. k="+k);
    }
    }
    new ImALocalInner().write();
}
}

