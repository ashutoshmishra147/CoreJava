class ArrayEx{
public static void main(String a[])
{
 int sum = 0;
 int[] arr = new int[5];
  for (int k=0; k < arr.length; k++)
	   sum += arr[k];
  for(int j:arr)
  {
	System.out.println(j);
}

}
}

//rextester java