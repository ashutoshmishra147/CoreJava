/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author LS5002117
 */
public class UserDefinedPropertiesDemo {
    public static void main(String args[]) throws FileNotFoundException, IOException {

        //Reading properties file in Java example
        Properties props = new Properties();
        FileInputStream fis = new FileInputStream("D:/Temp/jdbc.properties");
      
        //loading properites from properties file
        props.load(fis);

        //reading proeprty
        String username = props.getProperty("jdbc.username");
        String driver = props.getProperty("jdbc.driver");
        System.out.println("jdbc.username: " + username);
        System.out.println("jdbc.driver: " + driver);
        
        fis.close();
        System.out.println("----------------------------------");
        
        
        
        // Adding a new property to the file
        props.setProperty("propKey", "myNewPropValue");        
        FileOutputStream MyOutputStream = new FileOutputStream("D:/Temp/jdbc.properties");        
        props.store(MyOutputStream, "myAddedKey: myAddedValue");

        //Loading all the values from the property file
        FileInputStream fis1 = new FileInputStream("D:/Temp/jdbc.properties");
      
        //loading properites from properties file
        props.load(fis1);     
        String key = "";
        String value = "";
        for (Map.Entry<Object, Object> propItem : props.entrySet())
        {
            key = (String) propItem.getKey();
            value = (String) propItem.getValue();
            System.out.println(key+": " + value);
        }
        fis1.close();

    }

}
