/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

/**
 *
 * @author LS5002117
 */
public class SystemPropertiesDemo {
    public static void main(String[] args) {
         System.getProperties().list(System.out);
    }

}
