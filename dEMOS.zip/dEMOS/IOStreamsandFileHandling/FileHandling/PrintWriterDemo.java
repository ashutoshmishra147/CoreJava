/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

/**
 *
 * @author LS5002117
 */
import java.io.PrintWriter;


public class PrintWriterDemo {
    public static void main(String[] args) {
        PrintWriter printWriter = new PrintWriter(System.out, true);
        // Above step is for initialisin the Print Writer and makes everything
        // print to console
        // Print an int to console
        int i = 10; // 32 bit, range 2,147,483,648 and 2,147,484,647
        printWriter.println(i);
        
        // Print a String
        String name = "WWW.SYNTEL.COM";
        printWriter.println(name);

        byte b = 100; // 8-bits -128 to 127
        printWriter.println(b);


        byte asciValue = 'a';
        printWriter.println(asciValue);


        short noOfStudents = 32767; // 16 bit short int -32768 to 32767
        printWriter.println(noOfStudents);


        long distance = 64564; // 64 bit range -9,223,372,036,854,775,808 to
       // 9,223,372,036,854,775,807
        printWriter.println(distance);


        long days = 245885475475L;
        printWriter.println(days);


        float PI = 3.14F;// 32 bit range single precision
        printWriter.println(PI);


        double PIE = 3.14159; // 64 bit double precision
        printWriter.println(PIE);


        boolean result = true; // true or false
        printWriter.println(result);


        char driversLicenseClass = 'C'; // 16 bit
        printWriter.println(driversLicenseClass);  

    }
}


