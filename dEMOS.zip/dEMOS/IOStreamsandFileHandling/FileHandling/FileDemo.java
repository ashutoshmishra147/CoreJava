/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

import java.io.File;

/**
 *
 * @author LS5002117
 */
public class FileDemo {
    public static void main(String args[]) {
      File file = new File("D:/Temp/file1.txt");
      if (file.exists()) {
            System.out.println("The file exists");
            // is this a directory?
            if (file.isDirectory()) {
                System.out.println("The file is a directory");
                // List directory contents
                String[] dirContents = file.list();
            }

            // is this an ordinary file?
            if (file.isFile()) {
                System.out.println("The file is an ordinary file");
            }

            // is this file readable?
            if (file.canRead()) {
                System.out.println("I can read the file");
            }

            // is the file writable?
            if (file.canWrite()) {
                System.out.println("I can write to the file");
       }
       else
                System.out.println("Sorry the file doesn't exist.");    
    }

  }

}
