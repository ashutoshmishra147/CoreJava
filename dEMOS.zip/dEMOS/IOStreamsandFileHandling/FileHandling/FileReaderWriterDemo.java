/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;

/**
 *
 * @author LS5002117
 */
public class FileReaderWriterDemo {
    public static void main(String args[]) throws Exception { 
        String source = "This is an Example of File Reader and Writer\\n" 
        + " to show that we can read and write character by character\\n" 
        + " or an entire String."; 
        char buffer[] = new char[source.length()]; 
        source.getChars(0, source.length(), buffer, 0); 
        FileWriter f0 = new FileWriter("D:/Temp/file1.txt"); 
        for (int i=0; i < buffer.length; i += 2) { 
            f0.write(buffer[i]); 
        } 
        f0.close(); 
        FileWriter f1 = new FileWriter("D:/Temp/file2.txt"); 
            f1.write(buffer); 
        f1.close(); 
        
        //Lets now read the file which we have written
        FileReader fr = new FileReader("D:/Temp/file2.txt"); 
        BufferedReader br = new BufferedReader(fr); 
        String s; 
        while((s = br.readLine()) != null) { 
        System.out.println(s); 
        } 
        fr.close(); 
        } 

         
    } 


