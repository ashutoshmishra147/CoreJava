/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 *
 * @author LS5002117
 * 
 * Demo: Reads Data from the Console and Writes it to a file
 */
public class BufferedInputOutputDemo {
    public static void main(String[] args) throws Exception {
       // String fromFileName = "from.txt";
        String toFileName = "D:/Temp/to.txt";
        BufferedInputStream in = new BufferedInputStream(System.in);
        BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(toFileName));
        byte[] buff = new byte[32 * 1024];
        int len;
        while ((len = in.read(buff)) > 1){
             out.write(buff, 0, len);
             System.out.println("Length of Buffer:"+len+"/"+buff);
             
        }
           
        in.close();
        out.close();
  }

}
