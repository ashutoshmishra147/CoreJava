/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

/**
 *
 * @author LS5002117
 */
import java.io.*;
import java.util.Scanner;

public class ScannerToFile {
    public static Student register() {
        Student kid = new Student();
        Scanner scnr = new Scanner(System.in);
        
        System.out.println("Enter information about the student");
        System.out.print("Student ID: ");
        kid.StudentIdentificationNumber = scnr.nextInt();
        System.out.print("First Name: ");
        kid.FirstName = scnr.next();
        System.out.print("Last Name: ");
        kid.LastName = scnr.next();
        System.out.print("Number of credits so far: ");
        kid.CreditsSoFar = scnr.nextInt();
        System.out.print("Grade point average: ");
        kid.GPA = scnr.nextDouble();        
        return kid;
    }

    public static void save(Student pupil) throws Exception {
        String strFilename = "student.txt";
        Scanner scnr = new Scanner(System.in);
        
        System.out.print("Enter the file name: ");
        strFilename = scnr.next();
        
        // Make sure the user entered a valid file name
        if( !strFilename.equals("")) {
            // Indicate that you are planning to use a file
            File fleExample = new File(strFilename);
            // Create that file and prepare to write some values to it
            PrintWriter wrtStudent = new PrintWriter(fleExample);

            wrtStudent.println(pupil.StudentIdentificationNumber);
            wrtStudent.println(pupil.FirstName);
            wrtStudent.println(pupil.LastName);
            wrtStudent.println(pupil.CreditsSoFar);
            wrtStudent.println(pupil.GPA);
            
            // After using the PrintWriter object, de-allocated its memory
            wrtStudent.close();
            // For convenience, let the user know that the file has been created
            System.out.println("The file has been created.");
        }
    }
    
    public static void show(Student std) throws Exception {
        System.out.println("Student Record");
        System.out.println("Student ID: " + std.StudentIdentificationNumber);
        System.out.println("First Name: " + std.FirstName);
        System.out.println("Last Name: " + std.LastName);
        System.out.println("Number of credits so far: " + std.CreditsSoFar);
        System.out.println("Grade point average: " + std.GPA);
    }
    
    public static void main(String[] args) throws Exception {
        String answer = "n";
        Student std = register();
        Scanner scnr = new Scanner(System.in);
        
        System.out.print("Do you want to save this information (y/n)? ");
        answer = scnr.next();
        
        if( (answer.equals("y")) || (answer.equals("Y")) ) {
	    show(std);
            save(std);
        }
    }

}