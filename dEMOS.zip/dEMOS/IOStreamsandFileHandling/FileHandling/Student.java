/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

/**
 *
 * @author LS5002117
 */
public class Student {
    public int StudentIdentificationNumber;
    public String FirstName;
    public String LastName;
    public int CreditsSoFar;
    public double GPA;

    public Student() {
    }

    public int getCreditsSoFar() {
        return CreditsSoFar;
    }

    public void setCreditsSoFar(int CreditsSoFar) {
        this.CreditsSoFar = CreditsSoFar;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public int getStudentIdentificationNumber() {
        return StudentIdentificationNumber;
    }

    public void setStudentIdentificationNumber(int StudentIdentificationNumber) {
        this.StudentIdentificationNumber = StudentIdentificationNumber;
    }
    
    
}
