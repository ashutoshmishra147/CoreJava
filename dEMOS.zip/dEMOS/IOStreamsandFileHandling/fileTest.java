import java.io.*;
import java.util.Date;

public class fileTest {
   public static void main(String[] args) {

      File f = new File("d:\\java\\fileTest\\classes\\payroll.doc");
      File test1 = new File("d:\\java\\fileTest\\classes\\test1.doc");
      File test2 = new File("d:\\java\\fileTest\\classes\\test2.doc");
      File dir1 = new File("d:\\java\\fileTest\\classes\\payroll\\employee");
      File dir2 = new File("d:\\java\\fileTest\\classes\\payroll\\employee\\HR");
      File dir3 = new File("d:\\java\\fileTest\\classes\\payroll\\employee\\Sales"); 
      try {
         // Create a new file and rename
         test1.createNewFile();
         test1.renameTo(test2);

         // set test2 file as Read-Only 
         test2.setReadOnly();

         // Create some directories then delete one
         dir1.mkdirs();             // used for creating multiple directories
         dir2.mkdir();
         dir3.mkdir();
         dir3.delete();

         // First let check that it exists 
         if ( f.exists()) {
           // Let's test the object to see if its a file or directory
           if ( f.isFile() )
           {
              System.out.println("This file exists: " + f.getName());
              System.out.println("The absolute path of the file is: " + f.getAbsolutePath());
              System.out.println("getParent returns:" + f.getParent() + "\n");
              System.out.println("The canonical path of the file is: " + f.getCanonicalPath()); 

              System.out.println("Read the file:" + f.canRead());
              System.out.println("Write to the file:" + f.canWrite());

              System.out.println("File hidden:" + f.isHidden());
              long lm = f.lastModified();
              System.out.println("Last Modified:" + new Date(lm));

              System.out.println("Size of file: " + f.length()/1024 + "KB" );
           }
           else if (f.isDirectory()) {
                 System.out.println("This directory exists: " + f.getName());
                 System.out.println("The absolute path of the file is: " + f.getAbsolutePath());
           }
        } else {
             System.out.println("The file or directory does not exists: " + f.getName());
        }
      } catch (IOException e) {
           System.out.println("IOException caught" + e);
      }
   }
}
 
