/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class SuspendDemo implements Runnable {

    public void run() {
        try {
            Thread.sleep(10);
        } catch (Exception e) {
            System.out.println(e);
        }
        for (int i = 0; i <= 1; i++) {
            System.out.println(Thread.currentThread().getName() + " " + i);
        }
    }

    public static void main(String args[]) throws Exception {
        Thread th = new Thread(new SuspendDemo());
        Thread th1 = new Thread(new SuspendDemo());
        System.out.println("Starting " + th.getName() + "...");
        th.start();
        System.out.println("Suspending " + th.getName() + "...");
        //Suspend the thread.
        th.suspend();
        th1.start();
        th1.join();
        // Resume the thread.
        th.resume();
    }
} 