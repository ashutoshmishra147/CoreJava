/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class ActiveCount{
  public static void main(String args[]){
    new NewThread("A");
    new NewThread("B");
    new NewThread("C");
//    Returns the number of active threads in the current thread's thread group.
    System.out.println("Number of active threads is "+Thread.activeCount());
  }
}

class NewThread implements Runnable {
  Thread th;
  String str;
  public NewThread(String str){
    this.str=str;
    th=new Thread(this);
    th.start();    
  }
  public void  run(){
    for(int i=0;i<=10;i++){
      System.out.println(str+" " +i);
        
    }
  }
} 
