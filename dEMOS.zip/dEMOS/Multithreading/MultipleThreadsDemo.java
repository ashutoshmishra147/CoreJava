package Multithreading;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LS5002117
 */
public class MultipleThreadsDemo implements Runnable {

    Thread th;

    public void run() {
        for (int i = 0; i <= 2; i++) {

            System.out.println(Thread.currentThread().getName() + " " + i);
            try {
                //thread to sleep for the specified number of milliseconds 
                //plus the specified number of nanoseconds
                Thread.sleep(100, 10);
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    public static void main(String[] args) throws Exception {
        Thread th = new Thread(new MultipleThreadsDemo());
        th.start();

        Thread th1 = new Thread(new MultipleThreadsDemo());
        th1.start();
    }
} 