/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class Synchronized_MethodDemo extends Thread{
    static String msg[]={"This", "is", "an","example","to","show","what","happens","in","case","of","synchronized","method"};

    public Synchronized_MethodDemo(String name) {
        super(name);
    }   
    
    public void run(){
        for(int i=0;i<=12;i++)
            display(getName()+msg[i]);            
            try{
                this.sleep(50);
            }catch(Exception e){}
        
    }
    public synchronized void display(String threadN){
        System.out.println(threadN);
    }    
    
    public static void main(String args[]) {
      Synchronized_MethodDemo t1=new Synchronized_MethodDemo("1: ");
      t1.start();
      Synchronized_MethodDemo t2=new Synchronized_MethodDemo("2: ");
      t2.start();

   }

}
