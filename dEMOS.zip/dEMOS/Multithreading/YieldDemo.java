/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class YieldDemo implements Runnable {

    Thread th;

    public YieldDemo(String str) {
        th = new Thread(this, str);
        th.start();
    }

    public void run() {
        for (int i = 0; i < 10; i++) {
            // Yield control to another thread every
            // 10 iterations.
            if ((i % 10) == 0) {
                System.out.println(Thread.currentThread().getName() +
                        " is yielding control...");
                Thread.yield();
            }
        }

        System.out.println(Thread.currentThread().getName() +
                " has finished executing.");
    }

    public static void main(String[] args) {
        new YieldDemo("1st Thread ");
        new YieldDemo("2nd Thread ");
    }
} 