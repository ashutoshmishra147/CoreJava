/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package Multithreading;

/**
 *
 * @author LS5002117
 */
public class MainThreadDemo {
    public static void main(String args[])
    {
        Thread t = Thread.currentThread();
        t.setName("myThread");
        System.out.println("Default Thread");
        System.out.println(t);
        t.setPriority(3);
        System.out.println("After Setting Thread Priority");
        System.out.println(t);
    }
}

