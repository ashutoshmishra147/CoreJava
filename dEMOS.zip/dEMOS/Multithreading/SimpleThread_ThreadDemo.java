/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class SimpleThread_ThreadDemo extends Thread{
    public SimpleThread_ThreadDemo(String str) {
	super(str);
    }
    public void run() {
	for (int i = 0; i < 10; i++) {
	    System.out.println(i + " " + getName());
            try {
		sleep((int)(Math.random() * 1000));
	    } catch (InterruptedException e) {}
	}
	System.out.println("DONE! " + getName());
    }
    
    public static void main (String args[]) {
        new SimpleThread_ThreadDemo("First").start();       
    }

}
