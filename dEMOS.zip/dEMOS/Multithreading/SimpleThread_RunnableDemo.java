/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class SimpleThread_RunnableDemo implements Runnable{
    public SimpleThread_RunnableDemo(String str) {
	super();
    }
    public void run() {
	for (int i = 0; i < 10; i++) {
	    System.out.println(i + " " + Thread.currentThread().getName());
            try {
		Thread.sleep((int)(Math.random() * 1000));
	    } catch (InterruptedException e) {}
	}
	System.out.println("DONE! " + Thread.currentThread().getName());
    }
    
    public static void main (String args[]) {
        Runnable r=new SimpleThread_ThreadDemo("First");
        Thread t=new Thread(r);
        t.start();       
    }
    
}
