/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class IsAliveDemo implements Runnable {

    public void run() {
        Thread th = Thread.currentThread();
        //Tests if this thread is alive
        System.out.println(th.isAlive());
    }

    public static void main(String args[]) throws Exception {
        Thread th = new Thread(new IsAliveDemo());
        th.start();
        th.join();
        //Tests if this thread is alive
        System.out.println(th.isAlive());
    }
}  

