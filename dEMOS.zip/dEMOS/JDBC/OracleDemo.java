import java.sql.*;

public class OracleDemo {
    public static void  main ( String[] args)
{
 try {
            //Step1 - Register Driver
	 Class.forName("oracle.jdbc.driver.OracleDriver");
            //  Drivermanager.registerDriver("sun.jdbc.odbc.JdbcOdbcDriver");
           // Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //Type1 Driver JDBC-ODBC Bridge
 
	 System.out.println("Driver Registered");
    
	 //Step2 - Create Connection
//	 Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@172.25.56.46:1521:xe","hr", "hr");
	
	 Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.43.129:1521:xe","hr", "password");
          //Connection conn = DriverManager.getConnection("jdbc:odbc:oradsn","hr","password");
            System.out.println("Connected to Oracle DB");
//              //Step3 - Create Statement
              Statement st = conn.createStatement();
              //Step 4 - Generate Resultset
              ResultSet rs =   st.executeQuery("select * from employees");
                System.out.println("_____________________________________________________");
             System.out.println( "Emp No." + "First Name    ");
       System.out.println("_____________________________________________________");
             while(rs.next())
                 System.out.println(rs.getString(1)+ "    "+ rs.getString(2));
//        System.out.println("_____________________________________________________");
        } catch (Exception ex) {
             System.out.println(ex);
        }
    }
}