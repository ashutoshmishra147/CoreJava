//package k.syntel.training.jdkversion;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class JDK7Features {
	public static final Scanner input=new Scanner(System.in);
	/*
	1. String in Switch Expression
	2. Underscores Between Digits in Numeric Literals
	3. Integral Types as Binary Literals
	4. Handling multiple exceptions in a single catch block
	5. Try-with-resources Statement
	6. Automatic Type Inference in Generic object instantiation
	*/
	//String in Switch Expression
	public void switchWithString(){
		System.out.println("Enter Month");
		 String str1 = input.next();
		 String str2=null;
		 switch(str1)
		    {
		      case "January":str2 = "1st";  break;
		      case "February":str2 = "2nd";  break;
		      case "March":str2 = "3rd";  break;
		      case "April":str2 = "4th";  break;
		      case "May":str2 = "5th";  break;
		      case "June":str2 = "6th";  break;
		      case "July":str2 = "7th";  break;
		      case "August":str2 = "8th";  break;
		      case "September":str2 = "9th";  break;
		      case "October":str2 = "10h";  break;
		      case "November":str2 = "11th"; break;
		      case "December":str2 = "12th"; break;
		    }
		    System.out.println(str1 + " is " + str2 + " month in the year");
	}
	/*
	Underscores Between Digits in Numeric Literals
	Underscores are permitted in numeric literals. 
	You can place underscores where you feel required to increase readability; 
	like between hundreds and thousands, thousands and lakhs etc.
	This is used to group numbers in a bigger literal value (especially of long data type).
	Note: Do not place underscore at the beginning or ending of the literal value.
	*/
	//Underscores Between Digits in Numeric Literals
	public void numericLiterals(){
		int flatCost = 48_87_653;
		float buildingCost = 6_47_812.25_67f;
	    System.out.println("Flat cost Rs. " + flatCost);    
	    System.out.println("Building cost Rs. " + buildingCost);
	}
	/*
	With JDK 1.7, the integer whole numbers like byte, short, int and long 
	can be expressed in binary format also with a prefix of 0b or 0B. Earlier, 
	we have 0 prefix for octal and 0x prefix for hexa and no prefix for binary. 
	JDK 1.7, introduced 0b to represent binary literals.
	*/
	//Integral Types as Binary Literals
	public void binaryLiterals(){
		 int mangoCost = 0b00111011;
		 System.out.println("Mango cost Rs. " + mangoCost);    
 	     int intValue = 0b100_000_01;
  	     byte byteValue = (byte) 0b10000001;
	     System.out.println("0b10000001 as int:   " + intValue);    
	     System.out.println("0b10000001 as byte: " + byteValue);    
	    
	}
	/*
	Before JDK 1.7, it is required to write multiple catches to handle 
	different exceptions raised in the code. Now in a single catch statement, 
	multiple exceptions can be included separated by pipe ( | ) symbol.

	Following is the earlier to JDK 1.7 code which you are well familiar with.
	*/
	//Handling multiple exceptions in a single catch block
	public void singleCatchBlock(){
		 	int b =0, x[] = { 10, 20, 30 };
		    try
		    {
		      int c = x[3]/b;
		    }  
		    //Super class exception must be caught separately (it is a constraint).
		    catch(ArithmeticException | ArrayIndexOutOfBoundsException e)
		    {
		      System.out.println(e);    
		    }    
	    
	}
	/*
	 (try statement defining resources)

	 With JDK 1.7, no finally block is required to close (with close() methods) 
	 the resources of files or sockets or JDBC handles (objects) etc. The resources 
	 (say objects) opened in try block automatically close when the execution control 
	 passes out try block (say, at the close brace of try block).
	*/
	 //Try-with-resources Statement
	public void tryWithResources(){
		try (FileReader fr = new FileReader("abc.txt");FileWriter fw = new FileWriter("def.txt");)
		{
		  // some file copying code
		} // at this point fr and fw are closed
		catch (IOException e) 
		{
		   e.printStackTrace();
		} 
		/*
		Any resource (class) that implements interface "java.lang.AutoCloseable" is 
		eligible as a resource statement to write in try block. From JDK 1.7, many 
		classes implement AutoCloseable interface, like BufferedReader, PrintStream, Scanner, Socket etc.

		The close() method of AutoCloseable is called implicitly to close the handles. 
		Observe, the close() method throws Exception which you may or may not catch 
		if your code does not demand, or replace with problem specific exception class. In the above code, I used IOException. Note that close() method java.lang.Closeable interface is very different from this.

		JDBC 4.1 can make use of this try-catch-resource management. Following is 
		the snippet of code.
    	*/
	}
	/*
	(Diamond operator, <> , in collection classes)
	In JDK 1.7, empty angle brackets (known as diamond operator), <>, 
	can be used in specifying generic type instead of writing the exact one. But remember, the compiler should be able to judge the type from the generics statement you write.
	*/
	//Automatic Type Inference in Generic object instantiation
	public void automaticTypeInterence(){
		// List<String> namesList = new ArrayList<String>();  // Earlier style before JDK 1.7
	    List<String> namesList = new ArrayList<>();            // JDK 1.7 style
	    namesList.add("India S N Rao");
	    namesList.add("Canada Jyostna");
	    namesList.add("USA Jyothi");
	    for (String name: namesList) 
	    {
	      System.out.println(name);
	    }   
	}
	/*
	Static blocks
	Earlier to JDK 1.7, to print static blocks no main() method is required. 
	But from JDK 1.7, if no main() exists, static blocks will not be executed.
	*/
	static{
		System.out.println("This is static block");
	}
	
	public static void main(String[] args) {
		

	}

}
