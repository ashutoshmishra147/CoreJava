//package k.syntel.training.jdkversion;

/*
Java Functional Interfaces

An Interface that contains exactly one abstract method is known as functional interface. 
It can have any number of default, static methods but can contain only one abstract method.
 It can also declare methods of object class.

Functional Interface also known as Single Abstract Method Interfaces or SAM Interfaces.
It is a new feature in Java, which helps to achieve functional programming approach.
*/
@FunctionalInterface
interface Sayable3{  
    void say(); 
    static void print(){
    	System.out.println("static method allowed");
    }
    /*
    Java 8 introduces a new concept of default method implementation in interfaces. 
    This capability is added for backward compatibility so that old interfaces can 
    be used to leverage the lambda expression capability of Java 8.
    */ 
    default void display(){
    	System.out.println("default method allowed");
    }
}

class Test implements Sayable3{

	@Override
	public void say() {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void display() {
		Sayable3.super.display();
	}
	
}
public class JDK8FunctionalInterface {

	public static void main(String[] args) {
		Test test=new Test();
		test.display();
		test.say();
		Sayable3.print();
	}

}
