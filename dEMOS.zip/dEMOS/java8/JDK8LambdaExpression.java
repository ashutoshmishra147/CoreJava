//package k.syntel.training.jdkversion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
* In other words, we can say it is a replacement of java inner anonymous class. 
* Java lambda expression is treated as a function, so compiler does not create .class file.
*/
//Functional Interface
//Lambda expression provides implementation of functional interface. 
//An interface which has only one abstract method is called functional interface. 
//Java provides an anotation @FunctionalInterface, which is used to declare 
//an interface as functional interface.
//Why use Lambda Expression
//To provide the implementation of Functional interface.
//	Less coding.
//	Java Lambda Expression Syntax

//(argument-list) -> {body}  
//Java lambda expression is consisted of three components.
//1) Argument-list: It can be empty or non-empty as well.
//2) Arrow-token: It is used to link arguments-list and body of expression.
//3) Body: It contains expressions and statements for lambda expression.

@FunctionalInterface  //It is optional  
interface Drawable{  
    public void draw();  
}  
@FunctionalInterface
interface Sayable{  
    public String say(String name);  
}  
@FunctionalInterface
interface Addable{  
    int add(int a,int b);  
}
public class JDK8LambdaExpression {
	public static void main(String[] args) {
		 int width=10;  
		 Drawable d2=()->{System.out.println("Drawing "+width);};  //overriding method using lambda expr
	     d2.draw();
	     
	     Sayable s1=(name)->{return "Hello, "+name;};  //overriding the method
	     System.out.println(s1.say("Ram"));  
	     // You can omit function parentheses    
	     Sayable s2= name ->{return "Hello, "+name;}; //overriding the method
	     System.out.println(s2.say("Raj"));
	     
	     // Lambda expression without return keyword.  
	     Addable ad1=(a,b)->(a+b);  //override the method of the interface
	     System.out.println(ad1.add(10,20)); 
	     // Multiple parameters with data type in lambda expression
	     // Lambda expression with return keyword.  
	     Addable ad2=(int a,int b)->{return a+b;};  //override the method of the interface
	     System.out.println(ad2.add(100,200));
	     
	     List<String> list=new ArrayList<String>();  
	     list.add("ankit");  
	     list.add("mayank");  
	     list.add("irfan");  
	     list.add("jai");  
	          
	     list.forEach((n)->System.out.println(n));  
	     
	     // implementing lambda expression  
	     Collections.sort(list,(p1,p2)->{  
	     return p1.compareTo(p2);  
	     });  
	     for(String p:list){  
	     System.out.println(p);  
	     }  
	}
}
