//package k.syntel.training.jdkversion;

import java.util.function.BiFunction;

/*
Java Method References
Java provides a new feature called method reference in Java 8. 
Method reference is used to refer method of functional interface. 
It is compact and easy form of lambda expression. Each time when you are using 
lambda expression to just referring a method, you can replace your lambda 
expression with method reference. In this tutorial, we are explaining method 
reference concept in detail.

There are four types of method references:
Reference to a static method.
Reference to an instance method of a particular object.
Reference to an instance method of an arbitrary object of a particular type.
Reference to a constructor.
*/
interface Sayable1{  
    void say();  
}
class Arithmetic{  
public static int add(int a, int b){  
return a+b;  
}  
}  
interface Messageable{  
    Message getMessage(String msg);  
}  
class Message{  
    public Message(String msg){  
        System.out.print(msg);  
    }  
}  
public class JDK8MethodReference {
	public static void saySomething(){  
        System.out.println("Hello, this is static method.");  
    }  
	
	public void saySomething1(){  
        System.out.println("Hello, this is non-static method.");  
    }  
	
	public static void main(String[] args) {
		// Referring to a static method  
        Sayable1 sayable1 = JDK8MethodReference::saySomething;
        // Calling interface method  
        sayable1.say(); 
        
        BiFunction<Integer, Integer, Integer> adder = Arithmetic::add;  
        int result = adder.apply(10, 20);  
        System.out.println(result);  

        //Reference to an Instance Method
        JDK8MethodReference methodReference = new JDK8MethodReference(); // Creating object  
        // Referring non-static method using reference  
            Sayable1 sayable2 = methodReference::saySomething1;  
        // Calling interface method  
            sayable2.say();  
        // Referring non-static method using anonymous object
        // You can use anonymous object also
            Sayable1 sayable3 = new JDK8MethodReference()::saySomething1; 
        // Calling interface method  
            sayable3.say();  
            
        //Reference to a Constructor
            Messageable hello = Message::new;  
            hello.getMessage("Hello");
            
	}
	

}
