/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package Multithreading;

/**
 *
 * @author LS5002117
 */
public class Synchronized_BlockDemo extends Thread{
    static String msg[]={"This", "is", "an","example","to","show","what","happens","in","case","of","synchronized","method"};

    public Synchronized_BlockDemo(String name) {
        super(name);
    }   
    
    public void run(){
        synchronized(this){
            this.display(getName());
        }
    }
    public void display(String threadN){        
            for(int i=0;i<=12;i++)
                System.out.println(threadN+msg[i]);
                try{
                    this.sleep(2000);
                }catch(Exception e){}                
        
    }    
    
    public static void main(String args[]) {
      Synchronized_BlockDemo t1=new Synchronized_BlockDemo("1: ");
      t1.start();
      Synchronized_BlockDemo t2=new Synchronized_BlockDemo("2: ");
      t2.start();

   }

}
