/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//package Multithreading;

/**
 *
 * @author LS5002117
 */
public class UnSynchronizedThreadDemo extends Thread{
    static String msg[]={"This", "is", "an","example","to","show","what","happens","in","case","of","unsynchronized","threads"};

    public UnSynchronizedThreadDemo(String name) {
        super(name);
    }   
    
    public void run(){
        display(getName());
    }
    public void display(String threadN){
        for(int i=0;i<=12;i++)
            System.out.println(threadN+msg[i]);
            try{
                this.sleep(50);
            }catch(Exception e){}
    }    
    
    public static void main(String args[]) {
      UnSynchronizedThreadDemo t1=new UnSynchronizedThreadDemo("1: ");
      t1.start();
      UnSynchronizedThreadDemo t2=new UnSynchronizedThreadDemo("2: ");
      t2.start();

   }

}
