/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Multithreading;

/**
 *
 * @author LS5002117
 */
public class SetPriorityDemo implements Runnable {

    Thread th;

    public SetPriorityDemo() {
        th = new Thread(this);
        th.start();
    }

    public void run() {
        //get Priority of the thread
        System.out.println( th.getName()+" Priority "+th.getPriority());
        
        //set Priority of the thread
        th.setPriority(Thread.MAX_PRIORITY);
        
        //get Priority of the thread
        System.out.println(th.getName()+" New Priority "+th.getPriority());
    }

    public static void main(String[] args) {
        new SetPriorityDemo();
    }
} 
