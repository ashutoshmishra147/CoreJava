/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;

import java.util.HashMap;

/**
 *
 * @author LS5002117
 */
public class HashMapMovieOverridesEquals {
    public static void main(String[] args) {

		MovieOverridesEquals m = new MovieOverridesEquals();
		m.setActor("Akshay");
		m.setName("Thank You");
		m.setReleaseYr(2011);

		MovieOverridesEquals m1 = new MovieOverridesEquals();
		m1.setActor("Akshay");
		m1.setName("Khiladi");
		m1.setReleaseYr(1993);

		MovieOverridesEquals m2 = new MovieOverridesEquals();
		m2.setActor("Akshay");
		m2.setName("Taskvir");
		m2.setReleaseYr(2010);

		MovieOverridesEquals m3 = new MovieOverridesEquals();
		m3.setActor("Akshay");
		m3.setName("Taskvir");
		m3.setReleaseYr(2010);

		HashMap<MovieOverridesEquals, String> map = new HashMap<MovieOverridesEquals, String>();
		map.put(m, "ThankYou");
		map.put(m1, "Khiladi");
		map.put(m2, "Tasvir");
		map.put(m3, "Duplicate Tasvir");

		// Iterate over HashMap
		for (MovieOverridesEquals mm : map.keySet()) {
			System.out.println(map.get(mm).toString());
		}

		MovieOverridesEquals m4 = new MovieOverridesEquals();
		m4.setActor("Akshay");
		m4.setName("Taskvir");
		m4.setReleaseYr(2010);

		if (map.get(m4) == null) {
			System.out.println("----------------");
			System.out.println("Object not found");
			System.out.println("----------------");
		} else {
			System.out.println("----------------");
			System.out.println(map.get(m4).toString());
			System.out.println("----------------");
		}
	}

}
