/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;

/**
 *
 * @author LS5002117
 */
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo {

    public static void main(String[] args) {

        // TreeSet return in ordered elements
        TreeSet<String> ts=new TreeSet<String>();

        ts.add("b");
        ts.add("a");
        ts.add("d");
        ts.add("c");

        // get element in Iterator
        System.out.println("Normal Ordering Of Elements in Treeset");
        Iterator it=ts.iterator();
        while(it.hasNext())        {
          String value=(String)it.next();
          System.out.println("Value :"+value);
        }
        
        System.out.println("Treeset Elements in Descending Order");
        // get descending order of elements
        Iterator itd=ts.descendingIterator();

        while(itd.hasNext()){
          String value=(String)itd.next();
          System.out.println("Value :"+value);
        }
    }
}

