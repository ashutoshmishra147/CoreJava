/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;

/**
 *
 * @author LS5002117
 */
import java.util.HashMap;

class MovieOverridesEquals {
	private String name, actor;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}

	public int getReleaseYr() {
		return releaseYr;
	}

	public void setReleaseYr(int releaseYr) {
		this.releaseYr = releaseYr;
	}

	private int releaseYr;
        
        @Override
	public boolean equals(Object o) {
		MovieOverridesEquals m = (MovieOverridesEquals) o;
		return m.actor.equals(this.actor) && m.name.equals(this.name) && m.releaseYr == this.releaseYr;
	}

	@Override
	public int hashCode() {
		return actor.hashCode() + name.hashCode() + releaseYr;
	}


}


