
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SortArrayListDemo {
public static void main(String args[])
{
    ArrayList al = new ArrayList();
    al.add("Yogita");
    al.add("Selvam");
    al.add("Vaishali");
    al.add("Pawan");

 System.out.println("Using Iterator........");

    Iterator it = al.iterator();
    while(it.hasNext())
	    System.out.println(it.next());

 System.out.println("Enhanced For Loop........");
    //Enhanced For Loop
    for(Object obj : al)
	    System.out.println(obj);
  
    // Applying the Sort Argorithm
    Collections.sort(al);

    System.out.println("After Sorting........");
    //Enhanced For Loop
    for(Object obj : al)
    System.out.println(obj);

}
}
