package Collections;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LS5002117
 */
import java.util.*;

public class SearchDemo {
  public static void main(String[] args) {
    try{
        List<String> list = Arrays.asList("This","is","the","search","string");
        Collections.sort(list);
        System.out.println("The sorted list is: "+list);
        int pos = Collections.binarySearch(list, list.get(2));
        System.out.println("The position of the searched element is : "+pos 
        +" and the element is:"+list.get(2));
    }
    catch(Exception e){}
    }
}
