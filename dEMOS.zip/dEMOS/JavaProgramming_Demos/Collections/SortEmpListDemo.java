import java.util.*;

public class SortEmpListDemo {
public static void main(String args[])
{
    ArrayList al = new ArrayList();
    al.add(new Employee(111,"Rahul",23000));
    al.add(new Employee(112,"Vikas",24000));
    al.add(new Employee(115,"Alok",25000));
    al.add(new Employee(114,"Priyanka",21000));
    al.add(new Employee(113,"Vanita",27000));
    al.add("sdgfsdf");
    al.add(2345);

    System.out.println("Before Sorting........");
    for(Object obj : al)
    System.out.println(obj);

    Collections.sort(al);

    Collections.sort(al, new salcomp());
    System.out.println("Sorted by sal........");
    for(Object obj : al)
    System.out.println(obj);

    Collections.sort(al, new nocomp());
    System.out.println("Sorted by Employee No........");
    for(Object obj : al)
    System.out.println(obj);

    Collections.sort(al, new namecomp());
    System.out.println("Sorting by Name........");
    for(Object obj : al)
    System.out.println(obj);

}
}
