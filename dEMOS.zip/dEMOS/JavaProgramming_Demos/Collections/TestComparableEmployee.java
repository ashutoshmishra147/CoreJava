/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author LS5002117
 */
public class TestComparableEmployee {
        public static void main(String[] args) {

        List<ComparableEmployee> col = new ArrayList<ComparableEmployee>();

        col.add(new ComparableEmployee(5, "Frank", 28));
        col.add(new ComparableEmployee(1, "Jorge", 19));
        col.add(new ComparableEmployee(6, "Bill", 34));
        col.add(new ComparableEmployee(3, "Michel", 10));
        col.add(new ComparableEmployee(7, "Simpson", 8));
        col.add(new ComparableEmployee(4, "Clerk",16 ));
        col.add(new ComparableEmployee(8, "Lee", 40));
        col.add(new ComparableEmployee(2, "Mark", 30));



        Collections.sort(col);
        printList(col);
    }

    private static void printList(List<ComparableEmployee> list) {
        System.out.println("EmpId\tName\tAge");
        for (ComparableEmployee e: list) {
            System.out.println(e.getEmpId() + "\t" + e.getName() + "\t" + e.getAge());
        }
    }
}

