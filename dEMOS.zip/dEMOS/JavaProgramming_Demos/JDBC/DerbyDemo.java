import java.sql.*;
public class DerbyDemo {
public static void main(String args[]){
        try {
            //Step1 - Register Driver
            //    Driver dr  = new Driver();          
            Class.forName("org.apache.derby.jdbc.ClientDriver"); // Type 4 Driver Pure Java Driver
             //System.out.println("Driver Registered");
             //Step2 - Create Connection
             Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/sample","app","app");
              //System.out.println("Connected to Sample DB");
              //Step3 - Create Statement
              Statement st = con.createStatement();
              //Step 4 - Generate Resultset
              ResultSet rs =   st.executeQuery("select * from customer");
                System.out.println("_____________________________________________________");
              System.out.println("Customer Id \t Name \t City \t State");
        System.out.println("_____________________________________________________");
              while(rs.next())
                   System.out.println(rs.getInt("customer_id")+ "    "+ rs.getString("name")+ "    "+  rs.getString("city") +  "      " +rs.getString("state"));
        System.out.println("_____________________________________________________");
        } catch (Exception ex) {
             System.out.println(ex);
        }
  }
}