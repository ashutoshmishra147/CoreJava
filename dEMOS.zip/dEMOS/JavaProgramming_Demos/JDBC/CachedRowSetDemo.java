import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.*;
import javax.sql.rowset.CachedRowSet;

import oracle.jdbc.rowset.OracleCachedRowSet;


public class CachedRowSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		OracleCachedRowSet crs;

	    try{
		
	    crs = new OracleCachedRowSet();

	    crs.setUrl(" ");
	    crs.setUsername(" ");
	    crs.setPassword(" ");
	    crs.setReadOnly(false);
	    crs.setCommand("select * from employee_1 where empno=?");
	    crs.setInt(1, 40705);
       
       
	    // This will cause the RowSet to connect, fetch its data, and
	    // disconnect
	    crs.execute();
	    while (crs.next()) {
	    System.out.println("Selected Records: ");
	    System.out.println(crs.getInt(1)+"      "+crs.getString(2));
	    }

	    // Suppose we want to update data:
	    
	    crs.beforeFirst();
	    System.out.println("Updating Records: ");
	    while (crs.next()) {
	      if (crs.getInt("empno")== 40705) {
	    	
	        crs.updateString("ename", "Farhan");
	      
	        crs.updateRow(); 
	        
	        // This additional call tells the CachedRowSet to connect
	        // to its database and send the updated data back.
	       
	      }
	    }
	    crs.acceptChanges();

	    crs.beforeFirst();
	    while(crs.next()){
	    System.out.println("Updated Records: ");
	    System.out.println(crs.getInt(1)+"      "+crs.getString(2));
	    }
	    crs.close();
	    }catch(SQLException e){
	    	
	    	System.out.println(e);
	    	
	    }
	}

}
