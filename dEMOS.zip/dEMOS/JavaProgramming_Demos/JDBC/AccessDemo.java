import java.sql.*;

public class AccessDemo {
    public static void  main ( String[] args)
{
 try {
            //Step1 - Register Driver
            //  Drivermanager.registerDriver("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //Type1 Driver JDBC-ODBC Bridge
             System.out.println("Driver Registered");
             //Step2 - Create Connection
          Connection con = DriverManager.getConnection("jdbc:odbc:bibliodsn");
            System.out.println("Connected to Biblio DB");
//              //Step3 - Create Statement
              Statement st = con.createStatement();
              //Step 4 - Generate Resultset
              ResultSet rs =   st.executeQuery("select * from authors");
                System.out.println("_____________________________________________________");
             System.out.println("Author Id \t Name");
       System.out.println("_____________________________________________________");
             while(rs.next())
                 System.out.println(rs.getInt(1)+ "    "+ rs.getString(2));
//        System.out.println("_____________________________________________________");
        } catch (Exception ex) {
             System.out.println(ex);
        }
}
}