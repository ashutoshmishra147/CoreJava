import java.sql.*;

public class OracleDemo {
    public static void  main ( String[] args)
{
 try {
            //Step1 - Register Driver
            //  Drivermanager.registerDriver("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //Type1 Driver JDBC-ODBC Bridge
             System.out.println("Driver Registered");
             //Step2 - Create Connection
          Connection con = DriverManager.getConnection("jdbc:odbc:oradsn","trainee","trainee");
            System.out.println("Connected to Oracle DB");
//              //Step3 - Create Statement
              Statement st = con.createStatement();
              //Step 4 - Generate Resultset
              ResultSet rs =   st.executeQuery("select * from emp");
                System.out.println("_____________________________________________________");
             System.out.println( "Emp No." + "Name    ");
       System.out.println("_____________________________________________________");
             while(rs.next())
                 System.out.println(rs.getString(1)+ "    "+ rs.getString(2));
//        System.out.println("_____________________________________________________");
        } catch (Exception ex) {
             System.out.println(ex);
        }
    }
}