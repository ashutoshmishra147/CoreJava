import java.sql.*;

import oracle.jdbc.pool.OracleDataSource;


public class DataSourceDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       try{
		// Create a OracleDataSource instance explicitly
	    OracleDataSource ods = new OracleDataSource();

	    // Set the user name, password, driver type and network protocol
	    ods.setUser(" ");
	    ods.setPassword(" ");
	    ods.setDriverType(" ");
	    ods.setNetworkProtocol("tcp");
	    ods.setURL(" ");

	    // Retrieve a connection
	    Connection conn = ods.getConnection();
	 // Create a Statement
	    Statement stmt = conn.createStatement ();

	    // Select the NAME column from the Account_1 table
	    ResultSet rset = stmt.executeQuery ("select name from Account_1");
	    
	    System.out.println ("Account holder Names are:- ");
	    // Iterate through the result and print the Account holder names
	    while (rset.next ())
	      System.out.println ( rset.getString (1));

	    // Close the RseultSet
	    rset.close();
	    rset =  null;

	    // Close the Statement
	    stmt.close();
	    stmt = null;
	    // Close the connection
	    conn.close();
	    conn = null;
	  }catch(SQLException se){
		 
		  System.out.println ("Error :-"+se.getMessage()); 
	  }

	  
		
		
	}
}

