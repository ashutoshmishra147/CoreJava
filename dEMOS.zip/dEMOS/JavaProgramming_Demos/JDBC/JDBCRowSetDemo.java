import java.sql.*;

import javax.sql.rowset.*;

import oracle.jdbc.pool.OracleDataSource;
import oracle.jdbc.rowset.OracleJDBCRowSet;


public class JDBCRowSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 OracleJDBCRowSet jrs;
		//Load the driver
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException cnf)
		{
			System.out.println("Class for the driver not found");
		}

		try
		{
			jrs=new OracleJDBCRowSet();
			jrs.setUrl(" ");
			jrs.setUsername(" ");
			jrs.setPassword(" ");
			jrs.setType(ResultSet.TYPE_SCROLL_INSENSITIVE);
			//jrs.setType(ResultSet.TYPE_FORWARD_ONLY);
			jrs.setConcurrency(ResultSet.CONCUR_UPDATABLE);
			jrs.setCommand("select * from employee_1");
			jrs.execute();
		
			System.out.println("Emp No      EMP Name");
			System.out.println("_____________________");
			while(jrs.next()){
				
				
				System.out.println(jrs.getInt(1)+"           "+jrs.getString(2));
				
			}
			jrs.first();
			System.out.println(jrs.getInt(1)+"           "+jrs.getString(2));
			jrs.close();
			//con.close();


		}
		catch(SQLException se)
		{
			System.out.println("SQL exception due to "+se);
		}



	}

}
