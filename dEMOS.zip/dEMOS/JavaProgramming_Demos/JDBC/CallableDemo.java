import java.sql.*;

public class CallableDemo {
    public static void  main ( String[] args){
 try {
            //Step1 - Register Driver
            //  Drivermanager.registerDriver("sun.jdbc.odbc.JdbcOdbcDriver");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver"); //Type1 Driver JDBC-ODBC Bridge
             System.out.println("Driver Registered");
             //Step2 - Create Connection
          Connection con = DriverManager.getConnection("jdbc:odbc:oradsn","trainee","trainee");
            System.out.println("Connected to Oracle DB");
//              //Step3 - Create Statement
          //  String calladdition = "{ call addition(?, ?, ?) }";
                CallableStatement cs = con.prepareCall("{call addition(?,?,?)}");
                System.out.println("Calling Stored procedure.");
                cs.setInt(1,49);
                cs.setInt(2,34);
                // Step-5: register output parameters ...
                cs.registerOutParameter(3, java.sql.Types.VARCHAR);
                System.out.println("Setting parameter.");
               cs.execute();
                System.out.println("Executing Query.");
                String res = cs.getString(3);
                System.out.println("Addition : " + res);
        } catch (Exception ex) {
             System.out.println(ex);
        }
    }
}