import java.sql.*;
public class OraDemoType4 {
public static void main(String args[]){
        try {
            //Step1 - Register Driver
            //    Driver dr  = new Driver();        //jdbc.driver.oracle.OracleDriver
            Class.forName("oracle.jdbc.driver.OracleDriver"); // Type 4 Driver Pure Java Driver
             //System.out.println("Driver Registered");
             //Step2 - Create Connection
             Connection con = DriverManager.getConnection("jdbc:oracle:thin:@SYNARO00107.SYNTELEDU.COM:1521:XE","trainee","trainee");
              //System.out.println("Connected to Sample DB");
              //Step3 - Create Statement
              Statement st = con.createStatement();
              //Step 4 - Generate Resultset
              ResultSet rs =   st.executeQuery("select * from emp");
                System.out.println("_____________________________________________________");
              System.out.println("Emp Id \t Employee Name");
        System.out.println("_____________________________________________________");
              while(rs.next())
                   System.out.println(rs.getString(1)+ "    "+ rs.getString(2));
        System.out.println("_____________________________________________________");
        } catch (Exception ex) {
             System.out.println(ex);
        }
  }
}