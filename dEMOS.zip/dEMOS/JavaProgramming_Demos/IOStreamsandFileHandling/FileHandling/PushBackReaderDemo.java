/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package FileHandling;

import java.io.IOException;
import java.io.PushbackReader;
import java.io.StringReader;

/**
 *
 * @author LS5002117
 */
public class PushBackReaderDemo {
    public static void main(String[] args) {

      String s = "Hello World";

      // create a new StringReader
      StringReader sr = new StringReader(s);

      // create a new PushBack reader based on our string reader
      PushbackReader pr = new PushbackReader(sr, 20);
      
      try {
         // check if the reader is ready
         System.out.println("" + pr.ready());


         // read the first five chars
         for (int i = 0; i < 5; i++) {
            char c = (char) pr.read();
            System.out.print("" + c);
         }

         // change line
         System.out.println();

         // close the stream
         pr.close();

      } catch (IOException ex) {
         ex.printStackTrace();
      }
   }

}
